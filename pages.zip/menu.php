<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
          <div class="app-brand demo">
            <a href="dashboard.php" class="app-brand-link">
              <span >
                <a href="/">
                <img width="45" height="45" margin-left="none" fill="none"
                  
                  src="../assets/img/favicon/logo3.png"
                  />
              </a>
              </span>
              <span ><img width="140" height="30" margin-left="none"
                  
                  src="../assets/img/favicon/log6.png"
                  /></span>
            </a>

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto">
              <i class="ti menu-toggle-icon d-none d-xl-block ti-sm align-middle"></i>
              <i class="ti ti-x d-block d-xl-none ti-sm align-middle"></i>
            </a>
          </div>

          <div class="menu-inner-shadow"></div>

          <ul class="menu-inner py-1">
          
		   <br>
            <!-- Dashboards -->
            <li class="menu-item">
              <a href="dashboard.php" class="menu-link">
                <i class="menu-icon tf-icons ti ti-smart-home"></i>
                <div data-i18n="Dashboard">Dashboard</div>
               
              </a>
           
            </li>
			     <!-- Masters -->
            <li class="menu-header small text-uppercase">
              <span class="menu-header-text">Masters</span>
            </li>
           
            <li class="menu-item">
              <a href="master_page.php" class="menu-link">
                <i class="menu-icon tf-icons ti ti-layout-sidebar"></i>
                <div data-i18n="Masters">Masters</div>
              </a>

            </li>
			
				     <!-- Transactions -->
            <li class="menu-header small text-uppercase">
              <span class="menu-header-text">Transactions</span>
            </li>

            <!-- Front Pages -->
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-files"></i>
                <div data-i18n="Order">Order</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="enquiry.php" class="menu-link" >
                    <div data-i18n="Enquiry">Enquiry</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="sampleenquiry.php" class="menu-link" >
                    <div data-i18n="Sample Enquiry">Sample Enquiry</div>
                  </a>
                </li>
               
                <li class="menu-item">
                  <a href="order_confirm.php" class="menu-link" >
                    <div data-i18n="Order Confirmation">Order</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="sample.php" class="menu-link" >
                    <div data-i18n="Sample">Sample</div>
                  </a>
                </li>
               </ul>
            </li>
			
			<!-- Front Pages -->
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-layout"></i>
                <div data-i18n="Planning">Planning</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="fabric.php" class="menu-link" >
                    <div data-i18n="Fabric Plan">Fabric Plan</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="stitching.php" class="menu-link" >
                    <div data-i18n="Stitching Plan">Stitching Plan</div>
                  </a>
                </li>
                <li class="menu-item">
                          <a href="material_resource.php" class="menu-link" >
                            <div data-i18n="Material Resource Plan">Material Resource Plan</div>
                          </a>
                        </li>
                <li class="menu-item">
                  <a href="printing.php" class="menu-link" >
                    <div data-i18n="Printing Plan">Printing Plan</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="packing.php" class="menu-link" >
                    <div data-i18n="Packing Plan">Packing Plan</div>
                  </a>
                </li>
				
               </ul>
            </li>
			
	

				   <!--Costing-->
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-currency-dollar"></i>
                <div data-i18n="Costing">Costing</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="costing.php" class="menu-link" >
                    <div data-i18n="Costing">Costing</div>
                  </a>
                </li>
               </ul>
            </li>


				   <!--Fabric Computation-->
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-shirt"></i>
                <div data-i18n="Fabric Computation">Fabric Computation</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="fabric_computation.php" class="menu-link" >
                    <div data-i18n="Fabric Computation">Fabric Computation</div>
                  </a>
                </li>
               </ul>
            </li>


            <!--Purchase-->
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-shopping-cart"></i>
                <div data-i18n="Purchase">Purchase</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="purchaseorder.php" class="menu-link" >
                    <div data-i18n="Purchase Order">Purchase Order</div>
                  </a>
                </li>
              <li class="menu-item">
                  <a href="purchaseentry.php" class="menu-link" >
                    <div data-i18n="Purchase Entry">Purchase Entry</div>
                  </a>
                </li>
             
               </ul>
            </li>
			
			   <!--Time & Action-->
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-clock"></i>
                <div data-i18n="Time & Action">Time & Action</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="action_form.php" class="menu-link" >
                    <div data-i18n="Time & Action">Time & Action</div>
                  </a>
                </li>
               </ul>
            </li>
			
			 <!--Stores-->
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-package"></i>
                <div data-i18n="Stores">Stores</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="stockinward.php" class="menu-link" >
                    <div data-i18n="Inward">Inward</div>
                  </a>
                </li>
              <li class="menu-item">
                  <a href="stockoutward.php" class="menu-link" >
                    <div data-i18n="Outward">Outward</div>
                  </a>
                </li>
             
               </ul>
            </li>
			  <!--Invoice-->
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-clipboard"></i>
                <div data-i18n="Invoice">Invoice</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="sales_invoice.php" class="menu-link" >
                    <div data-i18n="Export Invoice">Export Invoice</div>
                  </a>
                </li>
           
             
               </ul>
            </li>
			
					<!--Reports-->
            <li class="menu-header small text-uppercase">
              <span class="menu-header-text">Reports</span>
            </li>

			  
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-receipt"></i>
                <div data-i18n="Order Reports">Order Reports</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="sales_report.php" class="menu-link" >
                    <div data-i18n="Sales Order">Sales Order</div>
                  </a>
                </li>
				<li class="menu-item">
                  <a href="ord_pending_report.php" class="menu-link" >
                    <div data-i18n="Order Pending">Order Pending</div>
                  </a>
                </li>
				
                <li class="menu-item">
                  <a href="sample_report.php" class="menu-link" >
                    <div data-i18n="Sample">Sample</div>
                  </a>
                </li>
				</ul>
			</li>
			
			<li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-map"></i>
                <div data-i18n="Planning">Planning Reports</div>
              </a>
              <ul class="menu-sub">
			
                <li class="menu-item">
                  <a href="fabric_plan_report.php" class="menu-link" >
                    <div data-i18n="Fabric Plan">Fabric Plan</div>
                  </a>
                </li>
				  <li class="menu-item">
                  <a href="mrp_report.php" class="menu-link" >
                    <div data-i18n="MRP Report">MRP Report</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="stitching_report.php" class="menu-link" >
                    <div data-i18n="Stitching">Stitching</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="printing_report.php" class="menu-link" >
                    <div data-i18n="Printing">Printing</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="packing_report.php" class="menu-link" >
                    <div data-i18n="Packing">Packing</div>
                  </a>
                </li>
			</ul>
			</li>
			
			<li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-briefcase"></i>
                <div data-i18n="Purchase">Purchase Reports</div>
              </a>
              <ul class="menu-sub">
              
                <li class="menu-item">
                  <a href="pur_ord_report.php" class="menu-link" >
                    <div data-i18n="Purchase Order">Purchase Order</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="pur_entry_report.php" class="menu-link" >
                    <div data-i18n="Purchase Entry">Purchase Entry</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="stock_inward_report.php" class="menu-link" >
                    <div data-i18n="Stock Inward">Stock Inward</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="stock_out_report.php" class="menu-link" >
                    <div data-i18n="Stock Outward">Stock Outward</div>
                  </a>
                </li>
			  </ul>
			  </li>
              
        <li class="menu-header small text-uppercase">
              <span class="menu-header-text">Settings</span>
            </li>
			
			<li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons ti ti-users"></i>
                <div data-i18n="Users">Users</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="usermaster.php" class="menu-link">
                    <div data-i18n="List">List</div>
                  </a>
                </li>
              </ul>
            </li>
             <li class="menu-item">
              <a href="https://truezor.com/" target="_blank" class="menu-link">
                <i class="menu-icon tf-icons ti ti-lifebuoy"></i>
                <div data-i18n="Support">Support</div>
              </a>
            </li>
               </ul>
            </li>
			
			  <!-- Report end  -->

			  <!-- Settings -->
            
           
            
         
          </ul>
        </aside>